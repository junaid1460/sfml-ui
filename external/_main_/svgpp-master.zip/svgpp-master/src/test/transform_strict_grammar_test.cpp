#define SVGPP_STRICT_TRANSFORM_SEPARATOR
#include "transform_grammar_test.cpp"