Licensing
====================

Library is free for commercial and non-commercial use. The library is licensed under the 
`Boost Software License, Version 1.0 <http://www.boost.org/LICENSE_1_0.txt>`_.

.. literalinclude:: ../../LICENSE_1_0.txt 
  :language: none
