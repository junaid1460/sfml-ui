***************************
Library Reference
***************************

.. toctree::
   document_traversal
   value
   length
   transform
   path
   basic_shapes
   color
   error
   iri
   markers
   viewport
   text