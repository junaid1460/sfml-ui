Install ftdetect, indent and syntax subdirectories to:

~/.vim/

See the vim documentation on this:

http://vimdoc.sourceforge.net/htmldoc/syntax.html#mysyntaxfile
